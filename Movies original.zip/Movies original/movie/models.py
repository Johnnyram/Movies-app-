from django.db import models
from django.db.models import Model
from embed_video.fields import EmbedVideoField

# Create your models here.

class Video(models.Model):
	name = models.CharField(max_length=64, null=True)
	video = EmbedVideoField()

	def __str__(self):
		return f'{self.name}'
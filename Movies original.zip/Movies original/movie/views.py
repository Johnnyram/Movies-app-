from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse
from django.shortcuts import redirect


from .models import Video


# Create your views here.
def index(request):
	videos = Video.objects.all()
	return render(request,"movie/index.html",{
		'videos':videos
	})

def login_view(request):
    return render(request, "movie/login.html")

def register(request):
    return render(request, "movie/register.html")

